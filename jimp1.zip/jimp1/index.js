var jimp = require('jimp');
 
jimp.read('yazu.jpg').then(function (img) {
 
    console.log(img);
 
}).catch (function (err) {
 
    console.log(err)
 
});

jimp.read("yazu.jpg", function (err, img) {
 
    img.resize(32,32)
   .write('small.jpg'); // save
 
});

// Same ratio code
jimp.read("yazu.jpg", function (err, img) {
 
    img.scaleToFit(756, jimp.AUTO, jimp.RESIZE_BEZIER)
   .write('same_ratio.jpg'); // save
 
});

//https://dustinpfister.github.io/2017/04/10/nodejs-jimp/

// open a file called "blues.jpg" in the source folder
/*

jimp.read('yazu.jpg', function (err, img) {
 
    var sizes = [64, 128, 756],
    quality = 5;
 
    if (err) {
 
        throw err;
 
    }
 
    // resize for all sizes
    sizes.forEach(function (size) {
 
        console.log('resize to: ' + size);
 
        // resize, and save to the build folder
        img.scaleToFit(size, jimp.AUTO, jimp.RESIZE_BEZIER)
        .quality(quality)
        .write('./blues_q_' + quality + '_s_' + size + '.jpg'); // save
 
    });
 
});*/